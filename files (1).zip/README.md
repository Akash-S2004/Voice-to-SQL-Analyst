# Voice → SQL Analyst (no-install edition)

Speak a business question in Tamil, Hindi or Hinglish. The app transcribes it with
**Gnani Prisma v3.0**, turns it into a read-only SQLite query, and shows the SQL,
the result table and a chart.

    voice ─► Gnani Prisma v3.0 (STT) ─► LLM (text-to-SQL) ─► safety check ─► SQLite ─► table + chart

This version uses ONLY Python's built-in libraries. There is nothing to pip install,
so it works on PCs where Windows Application Control blocks pandas and similar packages.

## Run it (Windows PowerShell)
    cd voice-sql-analyst
    python server.py

Your browser opens http://127.0.0.1:8000. If it does not, open that address yourself.
Stop the app with Ctrl+C.

(Optional) Pre-set keys instead of typing them in the page:
    $env:GNANI_API_KEY = "your-gnani-key"
    $env:LLM_API_KEY   = "your-llm-key"
    $env:LLM_BASE_URL  = "https://your-provider.example/v1"
    $env:LLM_MODEL     = "your-model-name"
    python server.py

## Check the logic without any keys
    python -m unittest test_core test_server -v

## Keys you need
- **Gnani API key**: app.gnani.ai → generate a key (the contest gives 5,000 credits).
- **An LLM key** for text-to-SQL: any OpenAI-compatible API. Set the base URL and model
  name from your provider's docs. If the LLM is unreachable the app falls back to a few
  keyword patterns so the demo still runs, but use the LLM for the real demo.

## How the microphone works
The page records from your microphone, converts it to a 16 kHz WAV in the browser
(Gnani does not list WebM), and sends it to the local server, which calls Gnani.
Use Chrome or Edge, and click Allow when the browser asks for the microphone.
Recordings stop automatically at 30 seconds (Gnani's REST limit).

## Gnani details this app follows (docs.gnani.ai)
- POST https://api.vachana.ai/stt/v3 with header X-API-Key-ID and multipart audio_file
- model=prisma-v3.0; language_code can be indic-auto, ta-IN, or a list like hi-IN,en-IN

## Safety
Only one SELECT/WITH statement is allowed; writes, PRAGMA, ATTACH and system tables are
blocked; the database is opened with PRAGMA query_only = ON; results are capped at 200 rows.
The server listens on 127.0.0.1 only, so nobody else on your network can reach it.
Keys you type are sent only from your browser to this local server, then to Gnani / your LLM.

## 60-second demo script
1. (0-5s) "Ask your data in Tamil, out loud."
2. (5-20s) Record: "கடந்த மாதம் எந்த பொருள் அதிகம் விற்பனை ஆனது?"
3. (20-35s) Show the transcript and the detected language (Gnani Prisma v3.0).
4. (35-55s) Show the generated SQL, the table and the chart.
5. (55-60s) "Built on Gnani Prisma v3.0. #GnaniAI #GreatIndianAIInternshipChallenge"

## Optional: Streamlit version
app.py is an alternative interface that needs `pip install -r requirements.txt`.
It will not run on a PC that blocks compiled packages. Use server.py there.
