"""Core logic for the Voice-to-SQL analyst.

No Streamlit imports here, so everything in this file can be tested on its own.

Pipeline:  voice  ->  Gnani Prisma v3.0 (speech-to-text)  ->  LLM (text-to-SQL)
           ->  safety check  ->  read-only SQLite  ->  table + chart
"""
from __future__ import annotations

import json
import random
import re
import sqlite3
import threading
import urllib.error
import urllib.request
import uuid
from datetime import date, timedelta

USER_AGENT = "voice-sql-analyst/1.0"

# --------------------------------------------------------------------------
# 0. Tiny HTTP helpers (standard library only, so nothing needs to be installed)
# --------------------------------------------------------------------------
def _post(url: str, headers: dict, body: bytes, timeout: int = 60) -> tuple[int, bytes]:
    """POST bytes and return (status, response_bytes). Raises ConnectionError on network failure."""
    req = urllib.request.Request(url, data=body, method="POST")
    req.add_header("User-Agent", USER_AGENT)
    for k, v in headers.items():
        req.add_header(k, v)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.status, resp.read()
    except urllib.error.HTTPError as exc:  # 4xx / 5xx still carry a useful body
        return exc.code, exc.read()
    except (urllib.error.URLError, TimeoutError, OSError) as exc:
        raise ConnectionError(str(exc)) from exc


def _multipart(fields: dict, file_field: str, filename: str, content: bytes, mime: str):
    """Build a multipart/form-data body. Returns (body_bytes, content_type)."""
    boundary = uuid.uuid4().hex
    safe_name = re.sub(r'[^A-Za-z0-9._-]', "_", filename) or "audio.wav"
    parts = []
    for key, value in fields.items():
        parts.append(
            f'--{boundary}\r\nContent-Disposition: form-data; name="{key}"\r\n\r\n{value}\r\n'.encode("utf-8")
        )
    parts.append(
        (
            f'--{boundary}\r\nContent-Disposition: form-data; name="{file_field}"; '
            f'filename="{safe_name}"\r\nContent-Type: {mime}\r\n\r\n'
        ).encode("utf-8")
        + content
        + b"\r\n"
    )
    parts.append(f"--{boundary}--\r\n".encode())
    return b"".join(parts), f"multipart/form-data; boundary={boundary}"


# --------------------------------------------------------------------------
# 1. Gnani speech-to-text (REST, Prisma v3.0)
#    Docs: https://docs.gnani.ai/api/STT/speech-to-text.md
# --------------------------------------------------------------------------
GNANI_STT_URL = "https://api.vachana.ai/stt/v3"
MAX_AUDIO_SECONDS = 30  # REST limit stated in the docs

MIME_BY_EXT = {
    "wav": "audio/wav",
    "mp3": "audio/mpeg",
    "ogg": "audio/ogg",
    "flac": "audio/flac",
    "aac": "audio/aac",
    "m4a": "audio/mp4",
}


class GnaniError(Exception):
    """Raised when the Gnani STT API returns an error."""


def transcribe(
    audio_bytes: bytes,
    filename: str,
    api_key: str,
    language_code: str = "indic-auto",
    fmt: str = "transcribe",
    topic: str | None = None,
    keyterms: list[str] | None = None,
    timeout: int = 60,
) -> dict:
    """Send audio to Gnani Prisma v3.0 and return the parsed JSON response.

    language_code: "indic-auto", one code such as "ta-IN", or a comma-separated
    list of up to 4 codes such as "hi-IN,en-IN" (Prisma v3.0 only).
    fmt: "transcribe" (numbers as digits), "codemix", "verbatim" or "transliterate".
    """
    if not api_key:
        raise GnaniError("Missing Gnani API key.")
    if not audio_bytes:
        raise GnaniError("No audio received.")

    ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else "wav"
    mime = MIME_BY_EXT.get(ext, "application/octet-stream")

    data = {"model": "prisma-v3.0", "language_code": language_code, "format": fmt}
    if topic:
        data["topic"] = topic[:1600]
    if keyterms:
        data["keyterms"] = json.dumps(keyterms[:200], ensure_ascii=False)

    body_bytes, content_type = _multipart(data, "audio_file", filename, audio_bytes, mime)
    headers = {
        "X-API-Key-ID": api_key,
        "X-API-Request-ID": str(uuid.uuid4()),
        "Content-Type": content_type,
    }

    try:
        status, raw = _post(GNANI_STT_URL, headers, body_bytes, timeout)
    except ConnectionError as exc:  # network problems
        raise GnaniError(f"Could not reach Gnani: {exc}") from exc

    try:
        body = json.loads(raw.decode("utf-8"))
    except ValueError:
        raise GnaniError(f"Unexpected response from Gnani (HTTP {status}).")

    if status == 200 and body.get("success"):
        return body

    # Error shapes documented by Gnani: envelope, gateway "detail", and 504 body.
    if isinstance(body.get("error"), dict):
        err = body["error"]
        raise GnaniError(f"{err.get('type', 'ERROR')}: {err.get('message', '')}")
    if isinstance(body.get("detail"), dict):
        det = body["detail"]
        raise GnaniError(f"{det.get('error_code', 'ERROR')}: {det.get('message', '')}")
    if isinstance(body.get("detail"), list):
        raise GnaniError("Invalid request (missing audio or language_code).")
    if body.get("code"):
        raise GnaniError(f"{body['code']}: {body.get('message', '')}")
    raise GnaniError(f"Gnani returned HTTP {status}.")


# --------------------------------------------------------------------------
# 2. Demo database (small-business sales, read-only)
# --------------------------------------------------------------------------
PRODUCTS = {  # product -> unit price (INR)
    "Rice": 62,
    "Idli Batter": 45,
    "Filter Coffee": 380,
    "Sambar Powder": 120,
    "Turmeric Powder": 95,
    "Ghee": 640,
    "Jaggery": 80,
    "Coconut Oil": 210,
}
REGIONS = ["Salem", "Coimbatore", "Chennai", "Madurai", "Bengaluru"]
DATA_START = date(2026, 5, 1)
DATA_END = date(2026, 10, 31)

SCHEMA_TEXT = """Table: sales
  order_id    INTEGER  primary key
  order_date  TEXT     ISO date 'YYYY-MM-DD' (data covers 2026-05-01 to 2026-10-31)
  product     TEXT     one of: {products}
  region      TEXT     one of: {regions}
  quantity    INTEGER  units sold
  unit_price  REAL     price per unit in INR
  revenue     REAL     quantity * unit_price, in INR""".format(
    products=", ".join(PRODUCTS), regions=", ".join(REGIONS)
)

_db_lock = threading.Lock()


def build_demo_db() -> sqlite3.Connection:
    """Create an in-memory SQLite DB with ~900 synthetic orders, then lock it read-only."""
    conn = sqlite3.connect(":memory:", check_same_thread=False)
    conn.execute(
        """CREATE TABLE sales (
            order_id INTEGER PRIMARY KEY,
            order_date TEXT NOT NULL,
            product TEXT NOT NULL,
            region TEXT NOT NULL,
            quantity INTEGER NOT NULL,
            unit_price REAL NOT NULL,
            revenue REAL NOT NULL)"""
    )
    rng = random.Random(42)  # fixed seed: same data every run
    names = list(PRODUCTS)
    product_weights = [10, 8, 5, 6, 5, 3, 4, 5]
    region_weights = [4, 5, 7, 4, 6]
    days = (DATA_END - DATA_START).days
    rows = []
    for order_id in range(1, 901):
        d = DATA_START + timedelta(days=rng.randint(0, days))
        product = rng.choices(names, weights=product_weights)[0]
        region = rng.choices(REGIONS, weights=region_weights)[0]
        qty = rng.randint(1, 20)
        price = float(PRODUCTS[product])
        rows.append((order_id, d.isoformat(), product, region, qty, price, qty * price))
    conn.executemany("INSERT INTO sales VALUES (?,?,?,?,?,?,?)", rows)
    conn.commit()
    conn.execute("PRAGMA query_only = ON")  # reject any write from now on
    return conn


# --------------------------------------------------------------------------
# 3. SQL safety + execution
# --------------------------------------------------------------------------
_FORBIDDEN = re.compile(
    r"\b(insert|update|delete|drop|alter|create|attach|detach|pragma|replace|"
    r"vacuum|reindex|truncate|load_extension)\b",
    re.IGNORECASE,
)


class UnsafeSQL(Exception):
    pass


def validate_sql(sql: str) -> str:
    """Return a cleaned, single read-only SELECT, or raise UnsafeSQL."""
    cleaned = (sql or "").strip().rstrip(";").strip()
    if not cleaned:
        raise UnsafeSQL("Empty query.")
    if ";" in cleaned:
        raise UnsafeSQL("Only one statement is allowed.")
    if not re.match(r"^(select|with)\b", cleaned, re.IGNORECASE):
        raise UnsafeSQL("Only SELECT queries are allowed.")
    if _FORBIDDEN.search(cleaned):
        raise UnsafeSQL("The query contains a forbidden keyword.")
    if "sqlite_" in cleaned.lower():
        raise UnsafeSQL("System tables are not available.")
    return cleaned


def run_query(conn: sqlite3.Connection, sql: str, max_rows: int = 200):
    """Validate and run a query. Returns (columns, rows)."""
    safe = validate_sql(sql)
    wrapped = f"SELECT * FROM ({safe}) LIMIT {int(max_rows)}"
    with _db_lock:
        cur = conn.execute(wrapped)
        columns = [c[0] for c in cur.description]
        rows = cur.fetchall()
    return columns, rows


def pick_chart(columns: list[str], rows: list[tuple]) -> str | None:
    """Return 'line', 'bar' or None for a result set."""
    if len(columns) < 2 or not rows or len(rows) > 60:
        return None
    if not all(isinstance(r[1], (int, float)) for r in rows):
        return None
    first = str(rows[0][0])
    if re.match(r"^\d{4}-\d{2}(-\d{2})?$", first):
        return "line"
    return "bar"


# --------------------------------------------------------------------------
# 4. Text-to-SQL (any OpenAI-compatible chat API) + offline fallback
# --------------------------------------------------------------------------
SYSTEM_PROMPT = f"""You turn business questions into ONE SQLite SELECT query.
The question may be in English, Tamil, Hindi, Hinglish or Tanglish (Tamil+English),
and may be written in native script or Latin letters. Map city and product names
in any script to the exact values listed in the schema (for example Tamil
"சேலம்" means Salem, Hindi "चेन्नई" means Chennai).

{SCHEMA_TEXT}

Rules:
- Use only the table `sales`. Output exactly one SELECT statement, no semicolons.
- "Last month" means 2026-10 (the latest month in the data). For months use
  strftime('%Y-%m', order_date).
- Give columns clear aliases. For "top N" questions use ORDER BY ... DESC LIMIT N.
- Revenue means SUM(revenue), in INR.
Reply with JSON only, no markdown:
{{"sql": "<the query>", "title": "<short English title for the result>"}}"""


class LLMError(Exception):
    pass


def llm_complete(messages, api_key: str, base_url: str, model: str, timeout: int = 60) -> str:
    """Call an OpenAI-compatible /chat/completions endpoint."""
    if not (api_key and base_url and model):
        raise LLMError("LLM key, base URL and model must all be set.")
    url = base_url.rstrip("/") + "/chat/completions"
    payload = json.dumps({"model": model, "messages": messages, "temperature": 0}).encode("utf-8")
    headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
    try:
        status, raw = _post(url, headers, payload, timeout)
    except ConnectionError as exc:
        raise LLMError(f"LLM request failed: {exc}") from exc
    text = raw.decode("utf-8", errors="replace")
    if status >= 400:
        raise LLMError(f"LLM request failed (HTTP {status}): {text[:200]}")
    try:
        return json.loads(text)["choices"][0]["message"]["content"]
    except (ValueError, KeyError, IndexError, TypeError) as exc:
        raise LLMError(f"Unexpected LLM response: {text[:200]}") from exc


def parse_llm_json(text: str) -> tuple[str, str]:
    """Pull {"sql":..., "title":...} out of a model reply (tolerates code fences)."""
    text = re.sub(r"```(?:json|sql)?", "", text or "").strip()
    match = re.search(r"\{.*\}", text, re.DOTALL)
    if not match:
        raise LLMError("The model did not return JSON.")
    try:
        obj = json.loads(match.group(0))
    except json.JSONDecodeError as exc:
        raise LLMError(f"Could not parse the model's JSON: {exc}") from exc
    sql = obj.get("sql", "")
    if not sql:
        raise LLMError("The model returned no SQL.")
    return sql, obj.get("title", "Result")


def question_to_sql(question: str, api_key: str, base_url: str, model: str) -> tuple[str, str]:
    messages = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": question},
    ]
    return parse_llm_json(llm_complete(messages, api_key, base_url, model))


# Offline fallback: a few keyword patterns (English, Hindi, Tamil) so the demo
# still runs if the LLM is unreachable. It is deliberately simple.
_FALLBACKS = [
    (
        ("region", "city", "area", "பகுதி", "ஊர்", "நகர", "इलाका", "शहर", "क्षेत्र"),
        "SELECT region, ROUND(SUM(revenue), 0) AS revenue FROM sales "
        "GROUP BY region ORDER BY revenue DESC",
        "Revenue by region",
    ),
    (
        ("month", "trend", "மாதம்", "महीना", "महीने"),
        "SELECT strftime('%Y-%m', order_date) AS month, ROUND(SUM(revenue), 0) AS revenue "
        "FROM sales GROUP BY month ORDER BY month",
        "Monthly revenue",
    ),
    (
        ("product", "item", "பொருள்", "प्रोडक्ट", "सामान", "उत्पाद"),
        "SELECT product, ROUND(SUM(revenue), 0) AS revenue FROM sales "
        "GROUP BY product ORDER BY revenue DESC LIMIT 5",
        "Top products by revenue",
    ),
    (
        ("total", "overall", "மொத்தம்", "कुल"),
        "SELECT ROUND(SUM(revenue), 0) AS total_revenue FROM sales",
        "Total revenue",
    ),
]


def fallback_sql(question: str) -> tuple[str, str] | None:
    q = (question or "").lower()
    for keys, sql, title in _FALLBACKS:
        if any(k in q for k in keys):
            return sql, title
    return None
