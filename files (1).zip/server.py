"""Voice -> SQL Analyst, no-install edition.

Uses ONLY Python's standard library (no pip, no pandas, no Streamlit), so it runs
on locked-down Windows PCs where compiled packages are blocked.

Run:  python server.py        then open http://127.0.0.1:8000
"""
import base64
import binascii
import io
import json
import os
import re
import sqlite3
import time
import wave
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import core

ROOT = Path(__file__).resolve().parent
MAX_BODY = 15 * 1024 * 1024  # 15 MB
LANG_RE = re.compile(r"^(indic-auto|[a-z]{2}-IN)(,[a-z]{2}-IN){0,3}$")
FORMATS = {"transcribe", "codemix", "verbatim"}
EXAMPLES = [
    "கடந்த மாதம் எந்த பொருள் அதிகம் விற்பனை ஆனது?",
    "Region wise total revenue dikhao",
    "சேலத்தில் மாதம் வாரியாக விற்பனை என்ன?",
    "Top 3 products by revenue in Chennai",
]

CONN = core.build_demo_db()


class ApiError(Exception):
    """An error whose message is safe to show to the user."""

    def __init__(self, message, status=400, extra=None):
        super().__init__(message)
        self.status = status
        self.extra = extra or {}


# ----------------------------------------------------------------- handlers
def handle_config(_payload=None):
    return {
        "gnani_key_set": bool(os.getenv("GNANI_API_KEY")),
        "llm_set": bool(
            os.getenv("LLM_API_KEY") and os.getenv("LLM_BASE_URL") and os.getenv("LLM_MODEL")
        ),
        "schema": core.SCHEMA_TEXT,
        "examples": EXAMPLES,
    }


def handle_transcribe(p):
    key = (p.get("gnani_key") or os.getenv("GNANI_API_KEY", "")).strip()
    if not key:
        raise ApiError("Add your Gnani API key in Settings first.")

    try:
        audio = base64.b64decode(p.get("audio_b64", ""), validate=True)
    except (binascii.Error, ValueError):
        raise ApiError("The audio upload was not valid.")
    if not audio:
        raise ApiError("No audio received. Record or choose a file first.")

    filename = re.sub(r"[^A-Za-z0-9._-]", "_", str(p.get("filename") or "audio.wav"))
    ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
    if ext not in core.MIME_BY_EXT:
        raise ApiError("Unsupported audio type. Use WAV, MP3, OGG, FLAC, AAC or M4A.")

    if ext == "wav":
        try:
            with wave.open(io.BytesIO(audio)) as w:
                secs = w.getnframes() / float(w.getframerate())
            if secs > core.MAX_AUDIO_SECONDS:
                raise ApiError(
                    f"The clip is {secs:.0f}s; Gnani's limit is {core.MAX_AUDIO_SECONDS}s."
                )
        except (wave.Error, EOFError):
            pass  # let Gnani decide

    language = str(p.get("language") or "indic-auto")
    if not LANG_RE.match(language):
        raise ApiError("Unknown language setting.")
    fmt = str(p.get("format") or "transcribe")
    if fmt not in FORMATS:
        raise ApiError("Unknown transcript style.")

    topic = keyterms = None
    if p.get("use_context"):
        topic = "Questions about sales, products, revenue, regions and months of a small food business"
        keyterms = list(core.PRODUCTS) + core.REGIONS

    t0 = time.time()
    try:
        result = core.transcribe(
            audio, filename, key, language_code=language, fmt=fmt, topic=topic, keyterms=keyterms
        )
    except core.GnaniError as exc:
        raise ApiError(f"Gnani speech-to-text failed: {exc}")
    return {
        "transcript": result.get("transcript", ""),
        "language": result.get("detected_language_code", "—"),
        "model": result.get("model", "prisma-v3.0"),
        "seconds": round(time.time() - t0, 2),
    }


def handle_ask(p):
    question = str(p.get("question") or "").strip()
    if not question:
        raise ApiError("Type or record a question first.")
    if len(question) > 500:
        raise ApiError("Please keep the question under 500 characters.")

    llm_key = (p.get("llm_key") or os.getenv("LLM_API_KEY", "")).strip()
    llm_base = (p.get("llm_base") or os.getenv("LLM_BASE_URL", "")).strip()
    llm_model = (p.get("llm_model") or os.getenv("LLM_MODEL", "")).strip()

    note = ""
    sql = title = None
    try:
        sql, title = core.question_to_sql(question, llm_key, llm_base, llm_model)
    except core.LLMError as exc:
        fb = core.fallback_sql(question) if p.get("use_fallback", True) else None
        if not fb:
            raise ApiError(f"Could not generate SQL: {exc}")
        sql, title = fb
        note = f"LLM unavailable ({exc}). Used the offline keyword fallback."

    try:
        columns, rows = core.run_query(CONN, sql)
    except core.UnsafeSQL as exc:
        raise ApiError(f"Blocked for safety: {exc}", extra={"sql": sql})
    except sqlite3.Error as exc:
        raise ApiError(f"The query failed: {exc}", extra={"sql": sql})

    return {
        "title": title,
        "sql": sql,
        "columns": columns,
        "rows": [list(r) for r in rows],
        "chart": core.pick_chart(columns, rows),
        "note": note,
    }


ROUTES_POST = {"/api/transcribe": handle_transcribe, "/api/ask": handle_ask}


# --------------------------------------------------------------- HTTP layer
class Handler(BaseHTTPRequestHandler):
    server_version = "VoiceSQL/1.0"

    def _send(self, status, body: bytes, ctype):
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(body)

    def _json(self, status, obj):
        self._send(status, json.dumps(obj, ensure_ascii=False).encode("utf-8"),
                   "application/json; charset=utf-8")

    def do_GET(self):
        if self.path in ("/", "/index.html"):
            self._send(200, (ROOT / "index.html").read_bytes(), "text/html; charset=utf-8")
        elif self.path == "/api/config":
            self._json(200, handle_config())
        else:
            self._json(404, {"error": "Not found"})

    def do_POST(self):
        handler = ROUTES_POST.get(self.path)
        if not handler:
            return self._json(404, {"error": "Not found"})
        if "application/json" not in (self.headers.get("Content-Type") or ""):
            return self._json(415, {"error": "Send JSON."})
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            length = 0
        if length <= 0 or length > MAX_BODY:
            return self._json(413, {"error": "Request is empty or too large."})
        try:
            payload = json.loads(self.rfile.read(length).decode("utf-8"))
            if not isinstance(payload, dict):
                raise ValueError
        except ValueError:
            return self._json(400, {"error": "Invalid JSON."})
        try:
            self._json(200, handler(payload))
        except ApiError as exc:
            self._json(exc.status, {"error": str(exc), **exc.extra})
        except Exception as exc:  # unexpected bug: keep details in the console only
            print("Unexpected error:", repr(exc))
            self._json(500, {"error": "Something went wrong inside the app. See the console."})

    def log_message(self, fmt, *args):  # quiet console
        pass


def make_server(port: int = 8000) -> ThreadingHTTPServer:
    # 127.0.0.1 only: the app is reachable from this computer, not from the network.
    return ThreadingHTTPServer(("127.0.0.1", port), Handler)


if __name__ == "__main__":
    port = int(os.getenv("PORT", "8000"))
    httpd = make_server(port)
    url = f"http://127.0.0.1:{port}"
    print(f"Voice -> SQL Analyst running at {url}   (Ctrl+C to stop)")
    try:
        webbrowser.open(url)
    except Exception:
        pass
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")
