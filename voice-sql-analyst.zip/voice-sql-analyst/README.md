# Voice → SQL Analyst

Speak a business question in Tamil, Hindi or Hinglish. The app transcribes it with
**Gnani Prisma v3.0**, turns it into a read-only SQLite query, and shows the SQL,
the result table and a chart.

    voice ─► Gnani Prisma v3.0 (STT) ─► LLM (text-to-SQL) ─► safety check ─► SQLite ─► table + chart

## Run it
    pip install -r requirements.txt
    cp .streamlit/secrets.toml.example .streamlit/secrets.toml   # add your keys
    streamlit run app.py

Check the logic without any keys: `python -m unittest test_core -v`

## Keys you need
- **Gnani API key**: app.gnani.ai → generate a key (the contest gives 5,000 credits).
- **An LLM key** for text-to-SQL: any OpenAI-compatible API (many providers have a
  free tier). Set `LLM_BASE_URL` and `LLM_MODEL` per your provider's docs.
  If the LLM is unreachable the app falls back to a few keyword patterns so the
  demo still runs, but for the real demo use the LLM.

## Gnani details this app follows (docs.gnani.ai)
- `POST https://api.vachana.ai/stt/v3`, header `X-API-Key-ID`, multipart `audio_file`
- `model=prisma-v3.0`; `language_code` can be `indic-auto`, `ta-IN`, or a list like `hi-IN,en-IN`
- Clips must be 30 seconds or less in the REST endpoint.

## Safety
Only one SELECT/WITH statement is allowed; writes, PRAGMA, ATTACH and system tables are
blocked; the database is opened with `PRAGMA query_only = ON`; results are capped at 200 rows.

## 60-second demo script
1. (0-5s) "Ask your data in Tamil, out loud."
2. (5-20s) Record: "கடந்த மாதம் எந்த பொருள் அதிகம் விற்பனை ஆனது?"
3. (20-35s) Show the transcript and the detected language (Gnani Prisma v3.0).
4. (35-55s) Show the generated SQL, the table and the chart.
5. (55-60s) "Built on Gnani Prisma v3.0. #GnaniAI #GreatIndianAIInternshipChallenge"

## Ideas if you have time left
- Add 2-3 more questions to the sample data (returns, stock, customers).
- Add Gnani Timbre text-to-speech to read the answer aloud in Tamil.
- Test with and without the "context hints" checkbox and keep whichever transcribes better.
