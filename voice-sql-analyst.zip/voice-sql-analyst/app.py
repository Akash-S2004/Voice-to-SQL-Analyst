"""Voice -> SQL Analyst: speak a business question in Tamil / Hindi / Hinglish,
get the SQL, the result table and a chart.

Speech recognition: Gnani Prisma v3.0 (https://docs.gnani.ai)
Run:  streamlit run app.py
"""
import io
import os
import time
import wave

import pandas as pd
import streamlit as st

import core

st.set_page_config(page_title="Voice → SQL Analyst", page_icon="🎙️", layout="wide")

LANGUAGES = {
    "Auto-detect (Prisma v3.0)": "indic-auto",
    "Tamil": "ta-IN",
    "Tamil + English (Tanglish)": "ta-IN,en-IN",
    "Hindi + English (Hinglish)": "hi-IN,en-IN",
    "Telugu": "te-IN",
    "Kannada": "kn-IN",
    "English (India)": "en-IN",
}
FORMATS = {
    "Transcribe (numbers as digits)": "transcribe",
    "Code-mix (English words stay in Latin)": "codemix",
    "Verbatim": "verbatim",
}
EXAMPLES = [
    "கடந்த மாதம் எந்த பொருள் அதிகம் விற்பனை ஆனது?",
    "Region wise total revenue dikhao",
    "சேலத்தில் மாதம் வாரியாக விற்பனை என்ன?",
    "Top 3 products by revenue in Chennai",
]


def setting(name: str, default: str = "") -> str:
    """Read a setting from environment variables, then Streamlit secrets."""
    value = os.getenv(name)
    if value:
        return value
    try:
        return str(st.secrets.get(name, default))
    except Exception:  # no secrets file
        return default


@st.cache_resource
def get_conn():
    return core.build_demo_db()


def wav_seconds(data: bytes):
    """Length of a WAV clip in seconds, or None if it is not a readable WAV."""
    try:
        with wave.open(io.BytesIO(data)) as w:
            return w.getnframes() / float(w.getframerate())
    except Exception:
        return None


conn = get_conn()
st.session_state.setdefault("question", "")

# ----------------------------------------------------------------- sidebar
with st.sidebar:
    st.header("Settings")
    gnani_key = st.text_input("Gnani API key", value=setting("GNANI_API_KEY"), type="password")
    lang_label = st.selectbox("Spoken language", list(LANGUAGES), index=0)
    fmt_label = st.selectbox("Transcript style", list(FORMATS), index=0)
    use_context = st.checkbox(
        "Send context hints (topic + product/city names)",
        value=True,
        help="Gnani notes that context can lower accuracy. Test with and without.",
    )

    with st.expander("Text-to-SQL model (any OpenAI-compatible API)"):
        llm_key = st.text_input("LLM API key", value=setting("LLM_API_KEY"), type="password")
        llm_base = st.text_input("Base URL", value=setting("LLM_BASE_URL"))
        llm_model = st.text_input("Model name", value=setting("LLM_MODEL"))
        use_fallback = st.checkbox("Use offline keyword fallback if the LLM fails", value=True)

    with st.expander("Demo database"):
        st.code(core.SCHEMA_TEXT, language="text")

# -------------------------------------------------------------------- main
st.title("🎙️ Voice → SQL Analyst")
st.caption(
    "Ask a business question by voice in Tamil, Hindi or Hinglish. "
    "Speech recognition runs on **Gnani Prisma v3.0**; the app turns your question "
    "into SQL and shows the answer."
)

st.subheader("1 · Speak your question")
recorded = st.audio_input("Record (up to 30 seconds)")
uploaded = st.file_uploader("…or upload an audio file", type=list(core.MIME_BY_EXT))
clip = recorded or uploaded

if clip is not None:
    audio_bytes = clip.getvalue()
    st.audio(audio_bytes)
    secs = wav_seconds(audio_bytes)
    too_long = secs is not None and secs > core.MAX_AUDIO_SECONDS
    if too_long:
        st.warning(f"This clip is {secs:.0f}s. Gnani's REST limit is {core.MAX_AUDIO_SECONDS}s.")
    if st.button("Transcribe with Gnani", disabled=too_long):
        topic = keyterms = None
        if use_context:
            topic = "Questions about sales, products, revenue, regions and months of a small food business"
            keyterms = list(core.PRODUCTS) + core.REGIONS
        try:
            with st.spinner("Listening…"):
                t0 = time.time()
                result = core.transcribe(
                    audio_bytes,
                    getattr(clip, "name", None) or "audio.wav",
                    gnani_key,
                    language_code=LANGUAGES[lang_label],
                    fmt=FORMATS[fmt_label],
                    topic=topic,
                    keyterms=keyterms,
                )
            st.session_state["question"] = result.get("transcript", "")
            st.session_state["stt_meta"] = {
                "language": result.get("detected_language_code", "—"),
                "model": result.get("model", "prisma-v3.0"),
                "seconds": round(time.time() - t0, 2),
            }
            if not st.session_state["question"]:
                st.warning("No speech was detected. Try again closer to the microphone.")
        except core.GnaniError as exc:
            st.error(f"Gnani speech-to-text failed: {exc}")

meta = st.session_state.get("stt_meta")
if meta:
    st.caption(
        f"Transcribed by Gnani {meta['model']} · detected language: {meta['language']} · "
        f"{meta['seconds']}s"
    )

st.subheader("2 · Check the question")
st.text_area(
    "What you asked (edit if the transcript needs a fix)",
    key="question",
    height=90,
    placeholder="Record above, or type a question here.",
)
st.caption("Try: " + "  ·  ".join(EXAMPLES))

st.subheader("3 · Get the answer")
question = st.session_state["question"].strip()
if st.button("Run", type="primary", disabled=not question):
    sql = title = None
    try:
        with st.spinner("Writing SQL…"):
            sql, title = core.question_to_sql(question, llm_key, llm_base, llm_model)
    except core.LLMError as exc:
        fb = core.fallback_sql(question) if use_fallback else None
        if fb:
            sql, title = fb
            st.warning(f"LLM unavailable ({exc}). Used the offline keyword fallback.")
        else:
            st.error(f"Could not generate SQL: {exc}")

    if sql:
        try:
            columns, rows = core.run_query(conn, sql)
        except core.UnsafeSQL as exc:
            st.error(f"Blocked for safety: {exc}")
        except Exception as exc:  # SQL error from SQLite
            st.error(f"The query failed: {exc}")
            st.code(sql, language="sql")
        else:
            st.markdown(f"#### {title}")
            st.code(sql, language="sql")
            if not rows:
                st.info("The query ran but returned no rows.")
            else:
                df = pd.DataFrame(rows, columns=columns)
                kind = core.pick_chart(columns, rows)
                left, right = st.columns([1, 1])
                with left:
                    st.dataframe(df, hide_index=True)
                    st.download_button(
                        "Download CSV", df.to_csv(index=False), "result.csv", "text/csv"
                    )
                with right:
                    if kind == "line":
                        st.line_chart(df.set_index(columns[0])[columns[1]])
                    elif kind == "bar":
                        st.bar_chart(df.set_index(columns[0])[columns[1]])
