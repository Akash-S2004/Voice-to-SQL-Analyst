"""Run with:  python -m unittest test_core -v   (no network needed)"""
import json
import sqlite3
import unittest
from unittest import mock

import core


class FakeResp:
    def __init__(self, status=200, body=None):
        self.status_code = status
        self._body = body

    def json(self):
        if self._body is None:
            raise ValueError("no json")
        return self._body

    def raise_for_status(self):
        if self.status_code >= 400:
            import requests
            raise requests.HTTPError(f"HTTP {self.status_code}")


class DatabaseTests(unittest.TestCase):
    def setUp(self):
        self.conn = core.build_demo_db()

    def test_seed(self):
        n = self.conn.execute("SELECT COUNT(*) FROM sales").fetchone()[0]
        self.assertEqual(n, 900)
        lo, hi = self.conn.execute("SELECT MIN(order_date), MAX(order_date) FROM sales").fetchone()
        self.assertGreaterEqual(lo, "2026-05-01")
        self.assertLessEqual(hi, "2026-10-31")

    def test_revenue_is_quantity_times_price(self):
        bad = self.conn.execute(
            "SELECT COUNT(*) FROM sales WHERE ABS(revenue - quantity*unit_price) > 0.001"
        ).fetchone()[0]
        self.assertEqual(bad, 0)

    def test_database_is_read_only(self):
        with self.assertRaises(sqlite3.OperationalError):
            self.conn.execute("DELETE FROM sales")

    def test_run_query_returns_rows_and_columns(self):
        cols, rows = core.run_query(
            self.conn, "SELECT region, SUM(revenue) AS r FROM sales GROUP BY region ORDER BY r DESC"
        )
        self.assertEqual(cols, ["region", "r"])
        self.assertEqual(len(rows), len(core.REGIONS))
        self.assertGreaterEqual(rows[0][1], rows[-1][1])  # order survives the LIMIT wrapper

    def test_row_limit(self):
        _, rows = core.run_query(self.conn, "SELECT * FROM sales", max_rows=50)
        self.assertEqual(len(rows), 50)


class SafetyTests(unittest.TestCase):
    def test_blocks_writes_and_multi_statement(self):
        for bad in [
            "DROP TABLE sales",
            "DELETE FROM sales",
            "SELECT 1; DROP TABLE sales",
            "UPDATE sales SET revenue = 0",
            "PRAGMA table_info(sales)",
            "SELECT * FROM sqlite_master",
            "ATTACH DATABASE 'x.db' AS x",
            "",
            "   ",
        ]:
            with self.assertRaises(core.UnsafeSQL, msg=bad):
                core.validate_sql(bad)

    def test_allows_select_and_with(self):
        self.assertTrue(core.validate_sql("SELECT 1;").startswith("SELECT"))
        self.assertTrue(
            core.validate_sql("WITH t AS (SELECT 1 AS a) SELECT a FROM t").startswith("WITH")
        )


class ChartTests(unittest.TestCase):
    def test_pick_chart(self):
        self.assertEqual(core.pick_chart(["month", "r"], [("2026-05", 1.0), ("2026-06", 2.0)]), "line")
        self.assertEqual(core.pick_chart(["region", "r"], [("Salem", 1.0), ("Chennai", 2.0)]), "bar")
        self.assertIsNone(core.pick_chart(["total"], [(5.0,)]))
        self.assertIsNone(core.pick_chart(["a", "b"], [("x", "text")]))


class LLMTests(unittest.TestCase):
    def test_parse_plain_and_fenced_json(self):
        sql, title = core.parse_llm_json('{"sql": "SELECT 1", "title": "One"}')
        self.assertEqual((sql, title), ("SELECT 1", "One"))
        fenced = '```json\n{"sql": "SELECT 2", "title": "Two"}\n```'
        self.assertEqual(core.parse_llm_json(fenced), ("SELECT 2", "Two"))

    def test_parse_rejects_garbage(self):
        with self.assertRaises(core.LLMError):
            core.parse_llm_json("sorry, I cannot help")
        with self.assertRaises(core.LLMError):
            core.parse_llm_json('{"title": "no sql"}')

    def test_question_to_sql_sends_schema_and_question(self):
        reply = {"choices": [{"message": {"content": '{"sql": "SELECT 1", "title": "T"}'}}]}
        with mock.patch("core.requests.post", return_value=FakeResp(200, reply)) as post:
            out = core.question_to_sql("சேலம் விற்பனை", "k", "https://llm.example/v1/", "m")
        self.assertEqual(out, ("SELECT 1", "T"))
        url = post.call_args.args[0]
        self.assertEqual(url, "https://llm.example/v1/chat/completions")
        sent = post.call_args.kwargs["json"]
        self.assertIn("Table: sales", sent["messages"][0]["content"])
        self.assertEqual(sent["messages"][1]["content"], "சேலம் விற்பனை")

    def test_missing_llm_settings(self):
        with self.assertRaises(core.LLMError):
            core.question_to_sql("hi", "", "", "")

    def test_fallbacks_run_on_real_db(self):
        conn = core.build_demo_db()
        for q in [
            "Region wise total revenue dikhao",
            "மாதம் வாரியாக விற்பனை",
            "कौन सा प्रोडक्ट सबसे ज्यादा बिका",
            "कुल बिक्री",
        ]:
            fb = core.fallback_sql(q)
            self.assertIsNotNone(fb, q)
            cols, rows = core.run_query(conn, fb[0])
            self.assertTrue(rows, q)
        self.assertIsNone(core.fallback_sql("what is the weather"))


class GnaniTests(unittest.TestCase):
    OK = {
        "success": True,
        "request_id": "x",
        "transcript": "கடந்த மாதம் எந்த பொருள் அதிகம் விற்பனை",
        "model": "prisma-v3.0",
        "detected_language_code": "ta-IN",
    }

    def test_request_matches_docs(self):
        with mock.patch("core.requests.post", return_value=FakeResp(200, self.OK)) as post:
            out = core.transcribe(
                b"RIFFxxxx", "audio.wav", "KEY",
                language_code="ta-IN,en-IN", fmt="transcribe",
                topic="sales", keyterms=["Salem", "ராகி"],
            )
        self.assertEqual(out["detected_language_code"], "ta-IN")
        args, kwargs = post.call_args
        self.assertEqual(args[0], "https://api.vachana.ai/stt/v3")
        self.assertEqual(kwargs["headers"]["X-API-Key-ID"], "KEY")
        self.assertIn("X-API-Request-ID", kwargs["headers"])
        self.assertEqual(kwargs["data"]["model"], "prisma-v3.0")
        self.assertEqual(kwargs["data"]["language_code"], "ta-IN,en-IN")
        self.assertEqual(kwargs["data"]["format"], "transcribe")
        self.assertEqual(json.loads(kwargs["data"]["keyterms"]), ["Salem", "ராகி"])
        name, content, mime = kwargs["files"]["audio_file"]
        self.assertEqual((name, content, mime), ("audio.wav", b"RIFFxxxx", "audio/wav"))

    def test_error_shapes(self):
        cases = [
            (400, {"success": False, "error": {"type": "MAX_AUDIO_DURATION_EXCEEDED", "message": "too long"}}, "MAX_AUDIO"),
            (401, {"detail": {"error_code": "INVALID_API_KEY", "message": "Unauthorized", "status_code": 401}}, "INVALID_API_KEY"),
            (422, {"detail": [{"type": "missing"}]}, "Invalid request"),
            (504, {"error": "Gateway Timeout", "code": "UPSTREAM_TIMEOUT", "message": "slow"}, "UPSTREAM_TIMEOUT"),
        ]
        for status, body, expect in cases:
            with mock.patch("core.requests.post", return_value=FakeResp(status, body)):
                with self.assertRaises(core.GnaniError) as ctx:
                    core.transcribe(b"x", "a.wav", "KEY")
            self.assertIn(expect, str(ctx.exception))

    def test_guards(self):
        with self.assertRaises(core.GnaniError):
            core.transcribe(b"x", "a.wav", "")
        with self.assertRaises(core.GnaniError):
            core.transcribe(b"", "a.wav", "KEY")

    def test_empty_transcript_is_not_an_error(self):
        body = {"success": True, "request_id": "x", "transcript": ""}
        with mock.patch("core.requests.post", return_value=FakeResp(200, body)):
            self.assertEqual(core.transcribe(b"x", "a.wav", "KEY")["transcript"], "")


if __name__ == "__main__":
    unittest.main()
